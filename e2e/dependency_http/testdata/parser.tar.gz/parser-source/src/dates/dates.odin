package dates

base :: proc() -> int {
	return 40
}
