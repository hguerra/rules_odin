package parser

import dates "dates"

answer :: proc() -> int {
	return dates.base() + 2
}
